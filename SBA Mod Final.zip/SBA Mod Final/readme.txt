Assessment Deliverables 

1. FrontEnd Source code 
-> In folder 1, also can be found https://github.com/huimiao/SBA_MentorOnDemand


2. Mid Tier Source code of all Microservices 
-> In folder 1, also can be found https://github.com/huimiao/SBA_MentorOnDemand


3. Screen shots of Usage of Post Man tool to test each End Point of all Microservices 
-> In folder 3


4. Few Steps on how to run the solution. 
-> 4.1 Create database per the model in the project
-> 4.2 Install Dokcker Desktop and kubenetes, refer https://github.com/AliyunContainerService/k8s-for-docker-desktop
-> 4.3 deploy mysql service using mysql-svc.yml in to kubenetes(you may need to change the file per your situation) and create a namespace named sba(kubectl create namespace sba)
-> 4.4 Start the backend serves one by one
   eureka-server -> gateway-zuul -> account-svc -> auth-svc ->technology-svc -> training-svc -> frontend -> batch-svc
   The deployment.yml file may be changed per your resuirement, for example the user id and password of mysql
OR
--> import into IDEA to run following the same sequence as 4.3(DB needs to be created first also and make change in the application.yml per your situation)

5. Test code of Angular and Mid Tier need to be included
-> code can be found in folder 1, and the screenshot of code coverate test of account service can be found in folder 5.


6. Jmeter�s JMX file to test atleast one REST End point, and Screenshot of report 
-> In folder 6


7. Dockerfile 
-> In the related Mid Tier Source code folder, also can be found https://github.com/huimiao/SBA_MentorOnDemand


8. Jenkinsfile 
-> In the related Mid Tier Source code folder, also can be found https://github.com/huimiao/SBA_MentorOnDemand


